@push('styles')
<style>
  .logo img {
    width: 150px;
}
</style>
@endpush
<div class="logo">
    <img src="{{ asset('images/white-logo.png') }}" class="" alt="Logo" class="">
</div>