<?php

namespace App\Filament\Resources\CompanyServicesResource\Pages;

use App\Filament\Resources\CompanyServicesResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateCompanyServices extends CreateRecord
{
    protected static string $resource = CompanyServicesResource::class;
}
