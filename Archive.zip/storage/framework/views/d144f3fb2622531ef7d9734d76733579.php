<?php $__env->startPush('styles'); ?>
<style>
  .logo img {
    width: 150px;
}
</style>
<?php $__env->stopPush(); ?>
<div class="logo">
    <img src="<?php echo e(asset('images/logo.png')); ?>" class="" alt="Logo" class="">
</div><?php /**PATH /Applications/MAMP/htdocs/CT_Portal/resources/views/brand.blade.php ENDPATH**/ ?>