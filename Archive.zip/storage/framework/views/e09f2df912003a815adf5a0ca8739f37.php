<?php $__env->startPush('styles'); ?>
<style>
  .logo img {
    width: 150px;
}
</style>
<?php $__env->stopPush(); ?>
<div class="logo">
    <img src="<?php echo e(asset('images/white-logo.png')); ?>" class="" alt="Logo" class="">
</div><?php /**PATH /Applications/MAMP/htdocs/CT_Portal/resources/views/brand-darkMode.blade.php ENDPATH**/ ?>